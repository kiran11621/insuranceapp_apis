﻿namespace insuranceapp.Models
{
    public class DeleteInsuranceResponse
    {
        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }
    }

}
